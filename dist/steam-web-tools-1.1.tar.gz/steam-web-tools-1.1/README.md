# Steam Web Tools
 A simple Python library to get information about Steam apps using their webpage
